
copy 8 records into "RESULTS" from stdin using delimiters ',','\n','' null as '';
101,H,1,10
103,H,1,5
102,H,1,9
103,M,1,7
101,M,1,12
102,M,1,9
101,H,2,8
102,H,2,9

