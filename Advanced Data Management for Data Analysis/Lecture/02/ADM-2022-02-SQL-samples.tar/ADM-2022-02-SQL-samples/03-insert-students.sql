
insert into "STUDENTS" values
(101,'Ann','Smith'),
(102,'Michael','Jones'),
(103,'Richard','Turner'),
(104,'Maria','Brown');

