#!/bin/bash
/home/pi/yetiborgv2/yeti2Joy.py > /dev/null

