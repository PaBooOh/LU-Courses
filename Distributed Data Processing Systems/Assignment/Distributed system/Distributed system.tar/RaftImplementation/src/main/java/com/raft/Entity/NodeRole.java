package com.raft.Entity;

public enum NodeRole {
    FOLLOWER,
    CANDIDATE,
    LEADER
}
